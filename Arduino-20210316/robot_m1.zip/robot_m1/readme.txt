
Charger sur l'Arduino arduino/moniteurArduino.ino

Lancer le programme node

- ouvrir un terminal, aller dans robot_m1/node

- si nécessaire supprimer le dossier node_modules et taper npm install pour recréer node_modules

- taper node robot.js

